#' This is function for demo
#'
#' @description The description of function
#' @usage download(accessionID)
#' @param id id
#download function
download <- function(id){
  #get the url
  url = paste("https://www.ncbi.nlm.nih.gov/sviewer/viewer.cgi?tool=portal&save=file&log$=seqview&db=nuccore&report=genbank&id=",id,"&conwithfeat=on&hide-cdd=on")
  #download file
  download.file(url,destfile = paste(id,".gb",sep = "",collapse = NULL))
  print(paste("Download ",id,".gb"))
}
