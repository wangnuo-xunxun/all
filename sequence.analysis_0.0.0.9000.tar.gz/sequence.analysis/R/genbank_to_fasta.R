#' This is function for demo
#'
#' @description The description of function
#' @usage genbank_fasta(genbank_file)
#' @param genbank_file genbank_file
#' @export
genbank_fasta <- function(genbank_file){
  genbank <- readLines(genbank_file)
  for (i in 1 : length(genbank)) {
    if(grepl("DEFINITION",genbank[i])){
      definition <- sub("DEFINITION","",genbank[i])
      if(grepl("ACCESSION",genbank[i+1])){
        definition <- paste(definition,sub("^\\S+\\t","",genbank[i+1]),sep = "")
      }
    }
    if(grepl("VERSION",genbank[i])){
      cat(sub("VERSION\\s+",">",genbank[i]),definition,"\n",file = sub("gb","fasta",genbank_file))
    }
    if(grepl("ORIGIN",genbank[i])){
      j <- i + 1
      for (k in j : length(genbank)) {
        cat(toupper(sub("\\s|//|>","",sub("\\s+[0-9]+\\s","",genbank[k]))),"\n",file = sub("gb","fasta",genbank_file),append = T)
      }
    }
  }
  print(paste("Translate ",genbank_file," to fasta"))
}
