#' This is function for demo
#'
#' @description The description of function
#' @usage alignment(file_1,file_2,match_score,gap_score,mismatch_score)
#' @param file_1 file_1
#' @param file_2 file_2
#' @param match_score match_score
#' @param gap_score gap_score
#' @param mismatch_score mismatch_score
#' @export
#alignment sequence
alignment <- function(file_1,file_2,match_score,gap_score,mismatch_score){
  #score
  match <- match_score
  gap <- gap_score
  mismatch <- mismatch_score
  #sequence
  A <- gsub("\\s","",paste(readLines(file_1)[2 : length(readLines(file_1))],collapse = NULL))
  B <- gsub("\\s","",paste(readLines(file_2)[2 : length(readLines(file_2))],collapse = NULL))
  #get the matrix
  colname <- strsplit(split = "", paste(sep = "", "-", A))
  rowname <- strsplit(split = "", paste(sep = "", "-", B))
  main <- matrix(nrow = length(rowname[[1]]), ncol = length(colname[[1]]), dimnames = list(rowname[[1]], colname[[1]]))
  main[1,1] <- 0
  for (i in 1 : nrow(main)) {
    for (j in 1 : ncol(main)) {
      if(i == 1 && j != 1){
        main[i,j] <- main[i,j-1] + gap
      }else if(j == 1 && i != 1){
        main[i,j] <- main[i-1,j] + gap
      }else if(i > 1 && j > 1){
        if(rownames(main)[i] == colnames(main)[j]){
          main[i,j] <- max(main[i-1,j-1] + match ,main[i-1,j] + gap ,main[i,j-1] + gap)
        }else{
          main[i,j] <- max(main[i-1,j-1] + mismatch ,main[i-1,j] + gap ,main[i,j-1] + gap)
        }
      }
    }
  }
  end_score <- main[nrow(main),ncol(main)]
  a <- colnames(main)[ncol(main)]
  b <- rownames(main)[nrow(main)]
  while (i != 2) {
    while (j != 2) {
      if(main[i,j] == main[i-1,j-1] + match|| main[i,j] == main[i-1,j-1] + mismatch){
        if(which.max(c(main[i-1,j-1],main[i-1,j],main[i,j-1])) == 1){
          j <- j - 1
          i <- i - 1
          a <- paste(sep = "",colnames(main)[j],a)
          b <- paste(sep = "",rownames(main)[i],b)
        }else if(which.max(c(main[i-1,j-1],main[i-1,j],main[i,j-1])) == 2){
          j <- j
          i <- i - 1
          a <- paste(sep = "","-",a)
          b <- paste(sep = "",rownames(main)[i],b)
        }else if(which.max(c(main[i-1,j-1],main[i-1,j],main[i,j-1])) == 3){
          j <- j - 1
          i <- i
          a <- paste(sep = "",colnames(main)[j],a)
          b <- paste(sep = "","-",b)
        }
      }else{
        if(which.max(c(main[i-1,j],main[i,j-1])) == 1){
          j <- j
          i <- i - 1
          a <- paste(sep = "","-",a)
          b <- paste(sep = "",rownames(main)[i],b)
        }else if(which.max(c(main[i-1,j],main[i,j-1])) == 2){
          j <- j - 1
          i <- i
          a <- paste(sep = "",colnames(main)[j],a)
          b <- paste(sep = "","-",b)
        }
      }
    }
  }
  print(paste("Alignment is finished.The score is",end_score,sep = ""))
  print(a)
  print(b)
  #calculate the Hamming Distance
  sequence_a <- strsplit(a,"")
  sequence_b <- strsplit(b,"")
  HammingDistance <- 0
  for (i in 1 : length(sequence_a[[1]])) {
    if(sequence_a[[1]][i] != sequence_b[[1]][i]){
      HammingDistance <- HammingDistance + 1
    }
  }
  print(paste("The Hamming Distance is",HammingDistance))
}
