#' This is function for demo
#'
#' @description The description of function
#' @usage make_file(accesion1,accession2,matchs,gaps,mismatchs)
#' @param accession1 accession1
#' @param accession2 accession2
#' @param matchs matchs
#' @param gaps gaps
#' @param mismatchs mismatchs
#' @importFrom download download
#' @importFrom genbank_to_fasta genbank_fasta
#' @importFrom alignment_sequence alignment
#' @export
maker_file <- function(accession1,accession2,matchs,gaps,mismatchs){
  download(accession1)
  download(accession2)
  genbank_fasta(paste(accession1,".gb",sep = "",collapse = NULL))
  genbank_fasta(paste(accession2,".gb",sep = "",collapse = NULL))
  alignment(paste(accession1,".fasta",sep = "",collapse = NULL),paste(accession2,".fasta",sep = "",collapse = NULL),matchs,gaps,mismatchs)
}
